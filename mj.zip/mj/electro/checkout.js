function insert()
{


if(z1!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product1' readonly='' name='product1' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z1*780+"' name=''></div>	</div>"	;
}
if(z2!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product2' readonly='' name='product2' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z2*780+"' name=''></div>	</div>"	;	
}
if(z3!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product3' readonly='' name='product3' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z3*780+"' name=''></div>	</div>"	;

}
if(z4!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product4' readonly='' name='product4' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z4*780+"' name=''></div>	</div>"	;
}
if(z5!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product5' readonly='' name='product5' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z5*780+"' name=''></div>	</div>"	;
}
if(z6!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product6' readonly='' name='product6' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z6*780+"' name=''></div>	</div>"	;
}
if(z7!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product7' readonly='' name='product7' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z7*780+"' name=''></div>	</div>"	;
}
if(z8!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product8' readonly='' name='product8' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z8*780+"' name=''></div>	</div>"	;
}
if(z9!=0)
{
document.getElementById('products').innerHTML=document.getElementById('products').innerHTML+ "<div class='order-col'> <div><input value='product9' readonly='' name='product9' class='trash' > </div><div><input type='' align='left' class='trash3' value='"+z9*780+"' name=''></div>	</div>"	;
}
alert("Le prix non entier est "+prix);
alert("le prix entier est "+prixn);
window.document.monform.prix.value=prix;

				}



insert();