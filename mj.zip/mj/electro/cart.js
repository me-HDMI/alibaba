var z1='0';
var z2='0';
var z3='0';
var z4='0';
var z5='0';
var z6='0';
var z7='0';
var z8='0';
var z9='0';
var prix='';
var n0='0';
var prixn=0;
var occ=0;
var prixold=0;
			function loli1()
		 {
		 alert('hi');
		 z1++;
        document.getElementById('cartnotif').innerHTML++;
        if(z1==1)
        {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product01.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product01</a></h3><h4 class='product-price'><span class='qty' id='product01'>"+z1+"</span><span id='prix1'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
		prixn=prixn+780;
		}
		else
			{
					t=document.getElementById('prix1').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z1;
			 document.getElementById('product01').innerHTML=string1;
			 
			 var string=x+'$';
			 alert('hello');
             document.getElementById('prix1').innerHTML=string;
              prixn=prixn+x;

             }
           getcookie();
       calculateN();
		changeprix1();
		}
		function loli2()
		{
		 alert('hi');
		 z2++;
		 document.getElementById('cartnotif').innerHTML++;
		 if(z2==1)
		 {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product02.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product02</a></h3><h4 class='product-price'><span class='qty' id='product02'>"+z2+"</span><span id='prix2'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	
		prixn=prixn+780;
		}
		else
			{
             	t=document.getElementById('prix2').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z2;
			 document.getElementById('product02').innerHTML=string1;
			
			 var string=x+'$';
			 alert('hello');
             document.getElementById('prix2').innerHTML=string;
              prixn=prixn+x;

             }
            getcookie();
       calculateN();
		changeprix1();
		}
		function loli3()
		{
		 alert('hi');
		 z3++;
		 document.getElementById('cartnotif').innerHTML++;
		 if(z3==1)
		 {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product03.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product03</a></h3><h4 class='product-price'><span class='qty' id='product03'>"+z3+"</span><span id='prix3'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	
	     prixn=prixn+780;
	     }
	     else
			{	
             	t=document.getElementById('prix3').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z3;
			 document.getElementById('product03').innerHTML=string1;
			 

			 var string=x+'$';
			 alert('hello');
             document.getElementById('prix3').innerHTML=string;
              prixn=prixn+x;

             }
           getcookie();
       calculateN();
		changeprix();
		}
		function loli4()
		{
		 alert('hi');
		 z4++;
		 document.getElementById('cartnotif').innerHTML++;
		 if(z4==1)
		 {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product04.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product04</a></h3><h4 class='product-price'><span class='qty' id='product04'>"+z4+"</span><span id='prix4'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	
         prixn=prixn+780;
         }
         else
			{	
             	t=document.getElementById('prix4').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z4;
			 document.getElementById('product04').innerHTML=string1;
			 
			 var string=x+'$';
			 alert('hello');
             document.getElementById('prix4').innerHTML=string;
              prixn=prixn+x;
             }
           getcookie();
       calculateN();
		changeprix1();
		}
		function loli5()
		{
			z5++;
		 alert('hi');
		 document.getElementById('cartnotif').innerHTML++;
		 if(z5==1)
		 {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product05.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product05</a></h3><h4 class='product-price'><span class='qty' id='product05'>"+z5+"</span><span id='prix5'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	
		prixn=prixn+780;

		}
		else
			{	
            	t=document.getElementById('prix5').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z5;
			 document.getElementById('product05').innerHTML=string1;
			 
			 var string=x+'TND';
			 alert('hello');
             document.getElementById('prix5').innerHTML=string;
              prixn=prixn+x;

             }
             getcookie();
       calculateN();
		changeprix1();
		}
		function loli6()
		{
		 alert('hi');
		 z6++;
		 document.getElementById('cartnotif').innerHTML++;
		 if(z6==1)
		 {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product06.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product06</a></h3><h4 class='product-price'><span class='qty' id='product06'>"+z6+"</span><span id='prix6'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
		prixn=prixn+780;	
		}
		else
			{	
             	t=document.getElementById('prix6').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z6;
			 document.getElementById('product06').innerHTML=string1;
			
			 var string=x+'TND';
			 alert('hello');
             document.getElementById('prix6').innerHTML=string;
              prixn=prixn+x;

             }
            getcookie();
     calculateN();
		changeprix1();
		}
		function loli7()
		{
		 alert('hi');
		 z7++;
		 document.getElementById('cartnotif').innerHTML++;
		 if(z7==1)
		 {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product07.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product07</a></h3><h4 class='product-price'><span class='qty' id='product07'>"+z7+"</span><span id='prix7'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
		prixn=prixn+780;	
		}
		else
			{	
             	t=document.getElementById('prix7').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z7;
			 document.getElementById('product07').innerHTML=string1;
			 
			 var string=x+'TND';
			 alert('hello');
             document.getElementById('prix7').innerHTML=string;
              prixn=prixn+x;

             }
             getcookie();
       calculateN();
		changeprix1();	
		}
		function loli8()
		{
		 alert('hi');
		  z8++;
             var x=0;    
		 document.getElementById('cartnotif').innerHTML++;
		 if(z8==1)
		 {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product08.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product08</a></h3><h4 class='product-price'><span class='qty'id='product08'>"+z8+"</span><span id='prix8'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
		prixn=prixn+780;	
		}
		else
			{
	t=document.getElementById('prix8').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z8;
			 document.getElementById('product08').innerHTML=string1;
			 
			 var string=x+'TND';
			 alert('hello');
             document.getElementById('prix8').innerHTML=string;
              prixn=prixn+x;

             }
             getcookie();
      calculateN();

		changeprix1();
             
		}
		function loli9()
		{
		 alert('hi');
	      x=0;
		
		 z9++;
		 document.getElementById('cartnotif').innerHTML++;
           if(z9==1)
           {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product09.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product09</a></h3><h4 class='product-price'><span class='qty' id='product09'>"+z9+"</span ><span id='prix9'> 780 TND </span> </h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
		    prixn=prixn+780;
			}
			else
			{
		t=document.getElementById('prix9').innerHTML;
			alert(t);
			var x=parseInt(t,10);
			alert(x);
			 var string1='x'+z9;
			 document.getElementById('product09').innerHTML=string1;
			
			 var string=x+'$';
			 alert('hello');
             document.getElementById('prix9').innerHTML=string;
              prixn=prixn+x;
             }
		
		getcookie();
		calculateN();
       changeprix1();
		
		 	
		}	



		function seteverything()
		{


	 z1=document.cookie[0];
     z2=document.cookie[1];
     z3=document.cookie[2];
       z4=document.cookie[3];
       z5=document.cookie[4];
       z6=document.cookie[5];
       z7=document.cookie[6];
       z8=document.cookie[7];
       z9=document.cookie[8];

       if(z9!=0)
       {
document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product09.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product09</a></h3><h4 class='product-price'><span class='qty' id='product09'>"+z9+"</span><span id='prix9'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	
        }
        if(z8!=0)
        {
 document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product08.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product08</a></h3><h4 class='product-price'><span class='qty'id='product08'>"+z8+"</span><span id='prix8'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
 	
        }
        if(z7!=0)
        {
document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product07.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product07</a></h3><h4 class='product-price'><span class='qty' id='product07'>"+z7+"</span><span id='prix7'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";

        }
        if(z6!=0)
        {
document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product06.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product06</a></h3><h4 class='product-price'><span class='qty' id='product06'>"+z6+"</span><span id='prix6'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
	       }
	       if(z5!=0)
	     {
document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product05.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product05</a></h3><h4 class='product-price'><span class='qty' id='product05'>"+z5+"</span><span id='prix5'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	
	     }
	     if(z4!=0)
	    { 
document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product04.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product04</a></h3><h4 class='product-price'><span class='qty' id='product04'>"+z4+"</span><span id='prix4'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";		
	    }
	    if(z3!=0)
	    {
document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product03.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product03</a></h3><h4 class='product-price'><span class='qty' id='product03'>"+z3+"</span><span id='prix3'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	
	    }
	    if(z2!=0)
	    {
		document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product02.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product02</a></h3><h4 class='product-price'><span class='qty' id='product02'>"+z2+"</span><span id='prix2'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";	

	    }
	    if(z1!=0)
	    {
document.getElementById('cart1').innerHTML=document.getElementById('cart1').innerHTML+"	<div class='product-widget'> <div class='product-img'><img src='./img/product01.png' alt=''></div><div class='product-body'><h3 class='product-name'><a href='#'>product01</a></h3><h4 class='product-price'><span class='qty' id='product01'>"+z1+"</span><span id='prix1'>780 TND</span></h4></div><button class='delete'><i class='fa fa-close'></i></button></div>";
	    }
       setcookie();
       changeprix(); 	
		}

         
function supp()
{
deleete();	
}

        function getcookie()
        {

        var v="";

    alert("it works");
   
    k=String(prixn);
        v=z1+z2+z3+z4+z5+z6+z7+z8+z9+k.length+prixn;
        alert("warri",v);
        document.cookie=v;
        alert("Le prixayay"+prixn);
        alert(document.cookie);	
        }


        function deleete()
        {
        v="00000000010";
        alert("ayayay"+v);
        document.cookie=v;	
        }



function calculateN()
{
   n1=parseInt(z1,20);
        n2=parseInt(z2,20);	
        n3=parseInt(z3,20);	
        n4=parseInt(z4,20);	
        n5=parseInt(z5,20);	
        n6=parseInt(z6,20);		
        n7=parseInt(z7,20);	
        n8=parseInt(z8,20);	
        n9=parseInt(z9,20);
     n0=n1+n2+n3+n4+n5+n6+n7+n8+n9;
}

function calculate()
 {
   calculateN();
          var n=parseInt(document.cookie[9]);
        alert("le nombre n est :!!!"+n);

        for(var i=10;i<9+n+1;i++)
        { 
        
        prix=prix+document.cookie[i]; 	
        }

 }

        function setcookie()
        {
     
calculate();
  alert(n0);
        
        alert("le prix est"+prix);
        }
		
		function changeprix1()
		{
        if(occ==0)
        {
        alert("Le prix old est"+prixold);	
        prixold=parseInt(prix);	
        occ++;
        prixn=prixn+prixold;
       }
        alert("nouveau prix est "+prixn)
		document.getElementById('cartnotif').innerHTML=n0;				
		document.getElementById('prixtot').innerHTML=prixn;
		}
        function changeprix()
        {
        document.getElementById('cartnotif').innerHTML=n0;				
		document.getElementById('prixtot').innerHTML=prix;	
        }  


		seteverything();