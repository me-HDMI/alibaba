
	<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<div id="myDiv">

</div>
<script type="text/javascript">
var data = [{
  x: ['decembre','janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre'],
  y: [<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==1)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==2)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==3)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==4)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==5)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==6)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==7)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==8)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==9)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==10)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==11)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM nb_clients ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_clients'];
	 if($occ==12)
	 {
	 echo $var1;
	 }
	}
	?>],

  type: 'line'
}];

Plotly.newPlot('myDiv', data, {}, {showSendToCloud:true});
</script>
<button><a href="supprimer.php">Supprimer</a></button>


