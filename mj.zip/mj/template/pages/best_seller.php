
	<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<div id="myDiv">

</div>
<script type="text/javascript">
var data = [{
  x: ['decembre','janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre'],
  y: [<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==1)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==2)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==3)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==4)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==5)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==6)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==7)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==8)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==9)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==10)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==11)
	 {
	 echo $var1;
	 }
	}
	?>,<?php
$host='localhost';
$user2='root';
$pass='';
$db='alibaba';
$co = new PDO("mysql:host=$host;dbname=$db",$user2, $pass);
$occ=0;

$sql = "SELECT * FROM best_seller ";
$query=$co->prepare($sql);

$query->execute();
$etat = $query->rowCount();

while ($data=$query->fetch()) 
{
	$occ++;
	  $var1=$data['nb_ventes'];
	 if($occ==12)
	 {
	 echo $var1;
	 }
	}
	?>],

  type: 'line'
}];

Plotly.newPlot('myDiv', data, {}, {showSendToCloud:true});
</script>
<button><a href="supprimer3.php">Supprimer</a></button>
